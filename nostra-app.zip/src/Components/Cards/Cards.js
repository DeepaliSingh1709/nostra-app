import React from "react";
import  "./Cards.css"

const Cards=(props)=>{

    return (
        props.map((a,i)=>{
            return(
            <div className="cardbox">
            <h5>Picks</h5>
            <div className="detailsbox">
            <img  src="/Assets/ind-min.png"/>
            <div >
                <h4>AFG VS BAN Test1</h4>
                <div><p>Test Day 2</p><span><img src="/Assets/live-min.png"/></span><p>Live Score Updates</p></div>
            </div>
            <img src="/Assets/flag-min.png"></img>
            </div>
            <div  className="rupes">
                <div>
                <img src="/Assets/ruppe-min.png"/>
                <span>8,000</span>
                </div>
                <div>
                <img src="/Assets/timer-min.png"/>
                <span>1 hr 58 min</span>
                </div>
            </div>

       </div>
        )}
        
    )
    )
}

export default Cards;