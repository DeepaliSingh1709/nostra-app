import React from "react";
import "./Header.css";

const Header=(props)=>{

    return (
        <div className="header">
            <h5>Home</h5>
        </div>
    )
}

export default Header;