import React from "react";
import "./BannerItem.css";

const BannerItem=(props)=>{

    return (
    <div className="banneritem">
      <img src={props.imagesrc}/>
    </div>
    )
}

export default BannerItem;