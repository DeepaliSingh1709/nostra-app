import React,{useState,useEffect} from 'react';
import Axios from "axios";
import Header from "./Components/Header/Header";
import Banner from "./Components/Banner/Banner";
import Tab from "./Components/Tab/Tab";
import Card from "./Components/Cards/Cards"
import './App.css';

function App() {

  let [data,setdata]=useState({
    banners:[],
    challenges:[],
    sports:[],
    user_name:""
  })
  useEffect(()=>{

    Axios.get("http://localhost:3000/home").then((res)=>{
      console.log(res.data);
      setdata(res.data);
    })

  },[])

  return (
    <div className="App">
    <Header></Header>
    <Banner bannerlist={data.banners}></Banner>
    <Tab></Tab>
    <Card cardlist={data.challenges}></Card>
    </div>
  );
}

export default App;
